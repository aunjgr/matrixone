import copy
import csv
import hashlib
import json
from pathlib import Path
import re
import shutil
import statistics
import subprocess

root=Path(__file__).resolve().parents[1]
payload=root/'bundle/payload'
native=Path('/home/aunjbr/codebase/work/matrixone/build/mo-input-coalescing-consumer/third_party/sirius')
old=Path('/home/aunjbr/codebase/work/matrixone/build/sirius-perf-release.zkConp/acceptance')
source=Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-embedded-cutover')
identity=json.loads((payload/'provenance/candidate-provenance-ac6.json').read_text())
assert json.loads((root/'work/native-state.json').read_text())['phase']=='complete'

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def write(name,value):
    (payload/name).write_text(json.dumps(value,indent=2,sort_keys=True)+'\n')

def receipt(name,allowed=(0,)):
    r=json.loads((root/'receipts'/(name+'.json')).read_text())
    assert r['exit_status'] in allowed,(name,r['exit_status'])
    assert sha(root/'receipts'/(name+'.log'))==r['output_sha256']
    return r

shutil.copytree(root/'work/resource',payload/'resource')
(payload/'profile-receipts').mkdir()
profiles=[]
for phase in range(1,7):
    allocation=json.loads((payload/f'resource/resource-phase-{phase}.json').read_text())
    assert allocation['provenance']==identity
    assert allocation['unexplained_growth_bytes']==0 and allocation['pool_baseline_reconciled']
    profiles.append(allocation)
    shutil.copyfile(root/f'work/resource-traces/phase-{phase}/receipt.json',payload/f'profile-receipts/phase-{phase}.json')
write('allocations.json',profiles)
shutil.copytree(root/'receipts',payload/'receipts')
shutil.copytree(old,payload/'historical-native',ignore=shutil.ignore_patterns('timing','baseline-timing','resource','numeric','proof','checksums.json','acceptance.json','allocations.json','matched-regression.json'))
write('provenance/native-binaries.json',json.loads((root/'work/native-binaries.json').read_text()))
execution={
 'qualification_target':identity,'native_binary_identities':json.loads((root/'work/native-binaries.json').read_text()),
 'native_production_sources':identity['sirius_revision'],
 'retained_gpu_executable_build_source_revision':'0cc6e484e0ee9dae3aa41919598116625d1abec8',
 'retained_cpu_control_build_source_revision':'b99fc7aec7edbc244a7c4a625998cd5a77e3a559',
 'qualification_basis':'Fresh executions of the retained native executables; production src tree is byte-identical between captured 0cc6e484 and target 06400cf4. Native CPU control src and embedding test trees are byte-identical between its b99fc7ae source and target. Actual binary hashes and fresh execution receipts are preserved.',
}

# Numeric manifests are rebuilt from this qualification's interleaved CSVs.
baselines=json.loads((old/'numeric-baselines.json').read_text())
baselines.pop('reuse_basis',None)
baselines['provenance']=identity;baselines['execution_context']=execution
baselines['raw_csv_sha256']={}
raw={}
for role in ('native-a','native-b','candidate'):
    values=[]
    for round in (1,2,3):
        name=f'numeric-{role}-{round}'
        receipt(name)
        path=payload/'receipts'/(name+'.log')
        values.extend(csv.DictReader(path.open()))
        baselines['raw_csv_sha256']['receipts/'+path.name]=sha(path)
    assert len(values)==(8 if role=='native-a' else 10)*21,(role,len(values))
    raw[role]=values
for case in baselines['cases']:
    for label,role in (('reference',case['reference']),('candidate','candidate')):
        values=[row for row in raw[role] if row['case']==case['id']]
        assert len(values)==21 and all(int(row['rows'])==262144 for row in values)
        case[label+'_seconds']=[float(row['wall_ms'])/1000 for row in values]
    case['candidate_revision']=identity['sirius_revision']
    case['candidate_build_revision']=baselines['identities']['candidate']['source_revision']
    case['candidate_binary_sha256']=execution['native_binary_identities']['candidate']['sha256']
    case['ratio']=statistics.median(case['candidate_seconds'])/statistics.median(case['reference_seconds'])
    case['passed']=case['ratio']<=1.10
    assert case['passed'],(case['id'],case['ratio'])
assert baselines['identities']['candidate']['binary_sha256']==execution['native_binary_identities']['candidate']['sha256']
baselines['identities']['candidate']['qualified_revision']=identity['sirius_revision']
write('numeric-baselines.json',baselines)

# A raw status 99 remains 99; accept only the exactly matched diagnostics.
names=('gpu-memcheck','cub-control','native-leakcheck','pinned-control')
parsed=[]
for name in names:
    r=receipt(name,(0,99));text=(payload/'receipts'/(name+'.log')).read_text()
    passed=re.findall(r'All tests passed \((\d+) assertions in (\d+) test cases?\)',text)
    errors=re.findall(r'ERROR SUMMARY: (\d+) errors?',text)
    leaks=re.findall(r'LEAK SUMMARY: ([\d,]+) bytes',text)
    assert passed and len(errors)==1 and r['exit_status']==99,(name,errors)
    leaked=int(leaks[0].replace(',','')) if leaks else 0
    assert (int(errors[0]),leaked)==(1,41386248 if name in names[2:] else 0),(name,errors,leaked)
    if name in names[:2]:assert text.count('Duplicate entry kernels named "_ZN3cub6detail11EmptyKernelIvEEvv"')==1
    parsed.append({'id':name+'.log','exit_status':r['exit_status'],'raw_error_count':int(errors[0]),
        'raw_leak_bytes':leaked,'sha256':r['output_sha256'],'passed_assertions_and_cases':[[int(a),int(b)] for a,b in passed]})
sanitizer=json.loads((old/'sanitizer.json').read_text())
sanitizer.pop('reuse_basis',None)
sanitizer['provenance']=identity;sanitizer['execution_context']=execution
sanitizer['parsed_raw_evidence']=parsed
sanitizer['raw_evidence_sha256']={r['id']:r['sha256'] for r in parsed}
sanitizer['runs']=[{k:v for k,v in r.items() if k in ('id','exit_status','raw_error_count','raw_leak_bytes')} for r in parsed]
sanitizer['evidence_sha256']=hashlib.sha256(json.dumps(parsed,sort_keys=True).encode()).hexdigest()
pinned,cub=sanitizer['reconciliations']
pinned['candidate_evidence_sha256']=parsed[2]['sha256'];pinned['control_evidence_sha256']=parsed[3]['sha256']
pinned['steady_profile_growth_bytes']=[p['unexplained_growth_bytes'] for p in profiles]
pinned['allocation_profile_proofs']=[{'file':f'resource-phase-{i}.json','sha256':sha(payload/f'resource/resource-phase-{i}.json'),
    'scale_factor':p['scale_factor'],'streams':p['streams'],'unexplained_growth_bytes':p['unexplained_growth_bytes']} for i,p in enumerate(profiles,1)]
cub['candidate_evidence_sha256']=parsed[0]['sha256'];cub['control_evidence_sha256']=parsed[1]['sha256']
assert cub['source_sha256']==sha(native/'src/cuda/scan/native_mo_input.cu')
header=Path('/home/aunjbr/codebase/work/matrixone/third_party/sirius/.pixi/envs/mo/targets/x86_64-linux/include/cccl/cub/util_device.cuh')
assert cub['no_op_header_sha256']==sha(header)
write('sanitizer.json',sanitizer)

# Each case points to the actual fresh invocation, binary, and barrier source.
for name in ('native-control','native-result','public-runner-race','native-gpu-owning','native-numeric'):receipt(name)
assert 'All tests passed (877 assertions in 93 test cases)' in (payload/'receipts/native-control.log').read_text()
for marker in ('unordered 96 MiB bounded result: passed','full-window cancellation and borrowed lifetime: passed',
               'full-window deadline and borrowed lifetime: passed','ordered 96 MiB result: passed'):
    assert marker in (payload/'receipts/native-result.log').read_text()
assert re.search(r'^ok\s', (payload/'receipts/public-runner-race.log').read_text(),re.M)
lifecycle=json.loads((old/'lifecycle.json').read_text());lifecycle.pop('reuse_basis',None)
lifecycle['provenance']=identity;lifecycle['execution_context']=execution
for case in lifecycle['cases']:
    result_case=case['id'] in ('paused-consumption','blocked-result-credit','cancel-during-work')
    writer=case['id']=='writer-failure'
    name='public-runner-race' if writer else 'native-result' if result_case else 'native-control'
    revision=identity['matrixone_revision'] if writer else '0cc6e484e0ee9dae3aa41919598116625d1abec8' if result_case else 'b99fc7aec7edbc244a7c4a625998cd5a77e3a559'
    prior=case['proof'];path=prior['source_path'];directory=source if writer else native
    data=subprocess.check_output(['git','-C',str(directory),'show',revision+':'+path])
    source_hash=hashlib.sha256(data).hexdigest()
    qualified=subprocess.check_output(['git','-C',str(directory),'show',(identity['matrixone_revision'] if writer else identity['sirius_revision'])+':'+path])
    assert data==qualified
    proof={'source_path':path,'source_revision':revision,'qualified_revision':identity['matrixone_revision'] if writer else identity['sirius_revision'],
           'source_sha256':source_hash,'execution_log':'receipts/'+name+'.log',
           'execution_log_sha256':sha(payload/'receipts'/(name+'.log')),
           'command_receipt':'receipts/'+name+'.json'}
    if not writer:proof['binary_sha256']=execution['native_binary_identities']['result' if result_case else 'control']['sha256']
    case['proof']=proof;case['evidence_sha256']=hashlib.sha256(json.dumps(proof,sort_keys=True).encode()).hexdigest()
    destination=payload/'proof-sources'/('mo' if writer else 'native')/path
    destination.parent.mkdir(parents=True,exist_ok=True);destination.write_bytes(data)
write('lifecycle.json',lifecycle)
write('checksums.json',{p.relative_to(payload).as_posix():sha(p) for p in sorted(payload.rglob('*')) if p.is_file() and p!=payload/'checksums.json'})
print(json.dumps({'assembled':True,'numeric_max_ratio':max(c['ratio'] for c in baselines['cases']),
                  'native_cases':len(lifecycle['cases']),'raw_sanitizer_status':sanitizer['raw_exit_status'],'raw_profiles':len(profiles)}))
