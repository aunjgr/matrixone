import os
from pathlib import Path
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
source = Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-embedded-cutover')
retained = Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-e-evidence-a1h40kk6')
command = [sys.executable, str(root/'bundle/tools/record_command.py'),
    '--receipt', str(root/'receipts/resource-recapture.json'),
    '--log', str(root/'receipts/resource-recapture.log'), '--cwd', str(source),
    '--env', 'PATH='+str(root/'archive-bin')+os.pathsep+os.environ['PATH'],
    '--env', 'NSYS_ARCHIVE_REAL=/usr/bin/nsys',
    '--env', 'NSYS_ARCHIVE_DIRECTORY='+str(root/'work/resource-traces'),
    '--', sys.executable, '-B', str(source/'optools/sirius_campaign.py'), 'run',
    '--workspace', str(retained/'candidate-workspace'),
    '--service', str(retained/'candidate-release/mo-service'),
    '--runner', '/home/aunjbr/codebase/work/matrixone/build/sirius-perf-release.zkConp/runner',
    '--provenance', str(retained/'candidate-provenance-ac6.json'),
    '--output', str(root/'work/resource'), '--resource']
raise SystemExit(subprocess.run(command, check=False).returncode)
