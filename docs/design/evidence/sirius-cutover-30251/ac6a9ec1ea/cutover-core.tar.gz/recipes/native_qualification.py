import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

root = Path(__file__).resolve().parents[1]
native = Path('/home/aunjbr/codebase/work/matrixone/build/mo-input-coalescing-consumer/third_party/sirius')
old = Path('/home/aunjbr/codebase/work/matrixone/build/sirius-perf-release.zkConp')
target = native/'build/mo/extension/sirius'
work = root/'work/native'
work.mkdir(exist_ok=True)
state = json.loads((root/'work/native-state.json').read_text()) if (root/'work/native-state.json').exists() else {'phase':'waiting-for-resource-campaign','passed':[]}
state.pop('error',None)

def save():
    (root/'work/native-state.json').write_text(json.dumps(state,indent=2)+'\n')

def run(name, command, allowed=(0,)):
    if name in state['passed']:
        prior=json.loads((root/'receipts'/(name+'.json')).read_text())
        assert prior['exit_status'] in allowed
        with (root/'receipts'/(name+'.log')).open('rb') as stream:
            assert hashlib.file_digest(stream,'sha256').hexdigest()==prior['output_sha256']
        return
    state['phase']=name;save()
    receipt=root/'receipts'/(name+'.json');log=root/'receipts'/(name+'.log')
    args=[sys.executable,str(root/'bundle/tools/record_command.py'),
          '--receipt',str(receipt),'--log',str(log),'--cwd',str(work),
          '--env','MO_SIRIUS_TEST_CONFIG='+str(work/'sirius.yaml'),
          '--','/usr/bin/timeout','--kill-after=30s','15m',*map(str,command)]
    code=subprocess.run(args,check=False).returncode
    if code not in allowed:raise RuntimeError(name+' exit '+str(code))
    state['passed'].append(name);save()

try:
    config='sirius:\n  space:\n    gpu:\n      - device_id: 0\n        memory_capacity: 6442450944\n    host:\n      - numa_id: -1\n        memory_capacity: 17179869184\n        block_size: 65536\n  telemetry:\n    output_directory: '+json.dumps(str(work/'telemetry'))+'\n'
    (work/'sirius.yaml').write_text(config)
    save()
    # Pure CPU control can run before the GPU qualification owns the device.
    run('native-control',[old/'native-control-normal'])
    while not (root/'receipts/resource-recapture.json').exists():time.sleep(1)
    resource=json.loads((root/'receipts/resource-recapture.json').read_text())
    if resource['exit_status']!=0:raise RuntimeError('resource capture failed')
    run('native-gpu-owning',[target/'sirius_native_gpu_unittest'])
    run('native-numeric',[target/'sirius_native_numeric_unittest','[native_numeric]'])
    run('native-result',[target/'sirius_native_result_integration',work/'sirius.yaml','2'])
    sanitizer='/home/aunjbr/codebase/work/matrixone/third_party/sirius/.pixi/envs/mo/bin/compute-sanitizer'
    run('gpu-memcheck',[sanitizer,'--tool','memcheck','--error-exitcode','99',target/'sirius_native_gpu_unittest','[exact_decimal_gpu],[decimal_import_gpu],[decimal_aggregate_gpu],[native_gpu],[native_result_gpu]'],(0,99))
    run('cub-control',[sanitizer,'--tool','memcheck','--error-exitcode','99',Path('/home/aunjbr/codebase/work/matrixone/build/sirius-native-a-baseline/build/mo/extension/sirius/sirius_native_gpu_unittest'),'native C producers execute on the real GPU scheduler'],(0,99))
    run('native-leakcheck',[sanitizer,'--tool','memcheck','--leak-check','full','--error-exitcode','99',target/'sirius_native_numeric_unittest','[native_numeric]'],(0,99))
    run('pinned-control',[sanitizer,'--tool','memcheck','--leak-check','full','--error-exitcode','99',target/'sirius_native_numeric_unittest','production exact ABI rejects raw numeric casts before GPU work'],(0,99))
    binaries={'native-a':Path('/home/aunjbr/codebase/work/matrixone/build/sirius-native-a-baseline/build/mo/extension/sirius/sirius_exact_decimal_benchmark'),
              'native-b':Path('/home/aunjbr/codebase/work/matrixone/build/sirius-native-b-baseline/build/mo/extension/sirius/sirius_exact_decimal_benchmark'),
              'candidate':target/'sirius_exact_decimal_benchmark'}
    for round,order in enumerate((('native-a','native-b','candidate'),('native-b','candidate','native-a'),('candidate','native-a','native-b')),1):
        for role in order:run('numeric-'+role+'-'+str(round),[binaries[role]])
    identities={}
    for role,path in {**binaries,'control':old/'native-control-normal','gpu':target/'sirius_native_gpu_unittest',
                       'numeric':target/'sirius_native_numeric_unittest','result':target/'sirius_native_result_integration'}.items():
        with path.open('rb') as stream:sha=hashlib.file_digest(stream,'sha256').hexdigest()
        identities[role]={'path':str(path),'sha256':sha,'bytes':path.stat().st_size}
    (root/'work/native-binaries.json').write_text(json.dumps(identities,indent=2)+'\n')
    state['phase']='complete';save()
except BaseException as error:
    state['phase']='failed';state['error']=str(error);save();raise
