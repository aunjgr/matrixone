import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parents[1]
payload = root/'bundle/payload'
payload.mkdir()
retained = Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-e-evidence-a1h40kk6')
source = Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-embedded-cutover')
native = Path('/home/aunjbr/codebase/work/matrixone/build/mo-input-coalescing-consumer/third_party/sirius')
head = 'ac6a9ec1ea234bca1ffabbaf59127536a7c5d978'
base = '17a6200f59e764729e5544908fffd5480ae88279'
ident = json.loads((retained/'candidate-provenance-ac6.json').read_text())

def sha(path):
    with path.open('rb') as stream:return hashlib.file_digest(stream,'sha256').hexdigest()

def git(directory,*arguments):
    return subprocess.check_output(['git','-C',str(directory),*arguments])

assert git(source,'rev-parse','HEAD').decode().strip()==head
assert not git(source,'status','--porcelain','--untracked-files=no')
for source_name,target in [('baseline-timing','baseline-timing'),('candidate-timing-ac6','timing'),('candidate-resource-ac6','original-resource')]:
    shutil.copytree(retained/source_name,payload/target)
(payload/'provenance').mkdir()
for name in ('baseline-provenance.json','candidate-provenance-ac6.json','matched-regression-final.json','offline-clone-identity.json','load-sf1.json','load-sf10.json','record.json','self-review.md','finish-e-qualification.py'):
    shutil.copyfile(retained/name,payload/'provenance'/name)

logs = ['cpu-build-owning.log','normal-race.log','normal-race-2.log','native-gpu-validation.log',
        'candidate-build-ac6.log','matched-release-build.log','native-cpu-pinned-build.log',
        'prepush-delivery-final.log','prepush-full-final.log','dataset-verification.log',
        'export-bridge-tests.log','compile-closure-2.log','orphan-hook-validation.log',
        'schema-coverage.log','campaign-python-3.log','python-final.log','gdb-real-exit-control.log']
(payload/'retained-logs').mkdir()
for name in logs:shutil.copyfile(retained/name,payload/'retained-logs'/name)

identity = {'head':head,'base':base,'binaries':{},'native_trees':{},'retained_logs':{}}
for role,path in [('candidate',retained/'candidate-release/mo-service'),
                  ('baseline',retained/'baseline-release/mo-service'),
                  ('sirius-only',retained/'sirius-only-release/mo-service'),
                  ('runner',Path('/home/aunjbr/codebase/work/matrixone/build/sirius-perf-release.zkConp/runner'))]:
    info=subprocess.check_output(['/usr/lib/go/bin/go','version','-m',str(path)],text=True)
    (payload/'provenance'/f'{role}-buildinfo.txt').write_text(info)
    identity['binaries'][role]={'sha256':sha(path),'bytes':path.stat().st_size,
        'buildinfo_file':f'provenance/{role}-buildinfo.txt'}
assert identity['binaries']['candidate']['sha256']==ident['service_binary_sha256']
assert identity['binaries']['runner']['sha256']==ident['runner_binary_sha256']
sdk=native/'build/mo/extension/sirius/embedding-sdk/link.json'
assert sha(sdk)==ident['sdk_sha256']
shutil.copyfile(sdk,payload/'provenance/sdk-link.json')
for revision in ('0cc6e484e0ee9dae3aa41919598116625d1abec8','b99fc7aec7edbc244a7c4a625998cd5a77e3a559',ident['sirius_revision']):
    identity['native_trees'][revision]={p:git(native,'rev-parse',revision+':'+p).decode().strip() for p in ('src','test/cpp/embedding','bench/mo_exact_decimal.cpp')}
native_diff=git(native,'diff','--name-status','0cc6e484e0ee9dae3aa41919598116625d1abec8',ident['sirius_revision']).decode()
identity['native_change_from_original_capture']=native_diff
assert native_diff=='M\ttest/cpp/embedding/test_native_execution_stats.cpp\n'
for p in ('pkg/cnservice/sirius_embedded.go','pkg/cnservice/sirius_embedded_native.go',
          'pkg/cnservice/sirius_runtime.go','pkg/cnservice/sirius_result.go',
          'pkg/sql/compile/siriusbridge','pkg/sql/compile/sirius_execution.go',
          'pkg/sql/compile/sirius_embedded_read.go','pkg/sql/compile/sirius_batch.go',
          'pkg/sql/plan/substrait','pkg/tests/sqlintegration/sirius_embedded_test.go'):
    assert not git(source,'diff','f3887d2526bd5c74625fa5556bb18c8c81b4dcf4',head,'--',p),p
identity['native_public_test_reuse']={
 'revision':'f3887d2526bd5c74625fa5556bb18c8c81b4dcf4',
 'reason':'All selected CN initialization/bridge/compiler/read/exporter and public fixture source trees are byte-identical to final head; final combined binary and fresh resource run are separately identified.',
 'status_kind':'retained terminal test/build log; no reconstructed command exit receipt',
}
for name in logs:
    p=payload/'retained-logs'/name
    identity['retained_logs'][name]={'sha256':sha(p),'bytes':p.stat().st_size,'status_kind':'retained-log'}

current_names=['sirius_campaign.py','sirius_campaign_v2.py','sirius_campaign_common.py',
               'sirius_resource.py','sirius_profile_exit.py','sirius_acceptance.py',
               'sirius_sdk.py','sirius_dataset.py']
base_names=['sirius_campaign.py','sirius_campaign_v2.py','sirius_parity.py',
            'sirius_resource.py','sirius_profile_exit.gdb','sirius_acceptance.py']
identity['source_files']={}
for revision,folder,names in ((head,'current',current_names),(base,'base',base_names)):
    destination=payload/'source'/folder
    destination.mkdir(parents=True)
    for name in names:
        data=git(source,'show',revision+':optools/'+name)
        path=destination/name;path.write_bytes(data)
        identity['source_files'][f'source/{folder}/{name}']={'revision':revision,'repository_path':'optools/'+name,'sha256':sha(path)}
configuration=retained/'candidate-workspace'
(payload/'configuration').mkdir()
for name in ('cn-2.toml','tn-2.toml','log-2.toml','sirius.yaml'):
    shutil.copyfile(configuration/name,payload/'configuration'/name)
runner=json.loads((configuration/'runner.json').read_text());runner['dsn']='<local-test-connection-redacted>'
(payload/'configuration/runner-redacted.json').write_text(json.dumps(runner,indent=2)+'\n')
(payload/'provenance/identity-audit.json').write_text(json.dumps(identity,indent=2)+'\n')
print(json.dumps({'retained_timing_runs_each':744,'original_resource_runs':264,
                  'candidate_binary_sha256':identity['binaries']['candidate']['sha256'],
                  'native_production_tree_equivalent':True,'public_native_test_sources_equivalent':True}))
