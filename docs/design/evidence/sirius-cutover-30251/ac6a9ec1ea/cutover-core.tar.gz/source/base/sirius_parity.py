#!/usr/bin/env python3
# Copyright 2026 Matrix Origin
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Deterministic Sirius TPCH parity/performance campaign orchestration.

The runner command receives one canonical JSON RunSpec in
MO_SIRIUS_CAMPAIGN_RUN and must print one JSON object. Accelerated routes must
report the query-local Sirius execution-stats contract through
``execution_stats``. This interface mirrors the additive Sirius ABI exactly
and is kept explicit while that ABI is integrated into MatrixOne.

This module never supplies a TPCH command and never starts concurrent GPU
work. The real executor is deployment-owned and is injected here.
"""

from __future__ import annotations

import argparse
import copy
import ctypes
import csv
import hashlib
import io
import json
import math
import os
from pathlib import Path
import select
import signal
import statistics
import subprocess
import sys
import threading
import time
from typing import Any, Callable, Iterable, Mapping, Sequence


SCHEMA_VERSION = 1
QUERIES = tuple(range(1, 23))
SCALE_FACTORS = (1, 10)
STREAMS = (1, 2, 4)
PERFORMANCE_STREAMS = 2
MEASURED_SUITES = 5
Q9_REPETITIONS = 10
# Reviewed design v2 section 5: one TAE staging unit is at most 8 MiB,
# immutable cached metadata is at most 32 MiB, and both the aggregate TAE host
# window and result window are 64 MiB.
TAE_HOST_WINDOW_BYTES = 64 << 20
TAE_STAGING_SLICE_BYTES = 8 << 20
TAE_METADATA_CACHE_BYTES = 32 << 20
RESULT_WINDOW_BYTES = 64 << 20
RESULT_SCHEMA_FIELDS = frozenset(("name", "type"))
RESULT_CELL_FIELDS = frozenset(("type", "value"))
FLOAT_SQL_TYPES = frozenset(("double", "float", "float32", "float64", "real"))
INTEGER_SQL_RANGES = {
    "tinyint": (-(1 << 7), (1 << 7) - 1),
    "smallint": (-(1 << 15), (1 << 15) - 1),
    "mediumint": (-(1 << 23), (1 << 23) - 1),
    "int": (-(1 << 31), (1 << 31) - 1),
    "integer": (-(1 << 31), (1 << 31) - 1),
    "bigint": (-(1 << 63), (1 << 63) - 1),
    "hugeint": (-(1 << 127), (1 << 127) - 1),
    "int8": (-(1 << 7), (1 << 7) - 1),
    "int16": (-(1 << 15), (1 << 15) - 1),
    "int32": (-(1 << 31), (1 << 31) - 1),
    "int64": (-(1 << 63), (1 << 63) - 1),
    "int128": (-(1 << 127), (1 << 127) - 1),
    "utinyint": (0, (1 << 8) - 1),
    "usmallint": (0, (1 << 16) - 1),
    "umediumint": (0, (1 << 24) - 1),
    "uinteger": (0, (1 << 32) - 1),
    "ubigint": (0, (1 << 64) - 1),
    "uhugeint": (0, (1 << 128) - 1),
    "uint8": (0, (1 << 8) - 1),
    "uint16": (0, (1 << 16) - 1),
    "uint32": (0, (1 << 32) - 1),
    "uint64": (0, (1 << 64) - 1),
    "uint128": (0, (1 << 128) - 1),
    "unsigned tinyint": (0, (1 << 8) - 1),
    "unsigned smallint": (0, (1 << 16) - 1),
    "unsigned mediumint": (0, (1 << 24) - 1),
    "unsigned int": (0, (1 << 32) - 1),
    "unsigned integer": (0, (1 << 32) - 1),
    "unsigned bigint": (0, (1 << 64) - 1),
    "tinyint unsigned": (0, (1 << 8) - 1),
    "smallint unsigned": (0, (1 << 16) - 1),
    "mediumint unsigned": (0, (1 << 24) - 1),
    "int unsigned": (0, (1 << 32) - 1),
    "integer unsigned": (0, (1 << 32) - 1),
    "bigint unsigned": (0, (1 << 64) - 1),
}
RUNNER_CLEANUP_TIMEOUT_SECONDS = 5.0
_PR_SET_CHILD_SUBREAPER = 36
_PR_GET_CHILD_SUBREAPER = 37
_SUBPROCESS_EXECUTOR_LOCK = threading.Lock()
ROUTES = (
    {"id": "mo-native", "backend": "native", "scan_mode": "mo"},
    {"id": "flight-tae", "backend": "flight", "scan_mode": "tae"},
    {"id": "flight-mo", "backend": "flight", "scan_mode": "mo"},
    {"id": "embedded-tae", "backend": "embedded", "scan_mode": "tae"},
    {"id": "embedded-mo", "backend": "embedded", "scan_mode": "mo"},
)
REQUIRED_PROVENANCE = (
    "matrixone_revision",
    "sirius_revision",
    "sidecar_revision",
    "sdk_sha256",
    "query_set_sha256",
    "query_sha256",
    "datasets",
    "hardware",
    "config",
)
HARDWARE_FIELDS = ("cpu", "gpu", "host_memory_bytes", "gpu_memory_bytes")
CONFIG_FIELDS = ("sha256", "cuda_version", "driver_version")
REQUIRED_EXECUTION_STATS = (
    "source_mask",
    "terminal",
    "terminal_status",
    "fatal",
    "gpu_tasks_started",
    "gpu_tasks_completed",
    "mo_input_units",
    "mo_input_retained_charged_bytes",
    "mo_input_peak_charged_bytes",
    "mo_input_blocked_acquires",
    "tae_requests",
    "tae_work_issued",
    "tae_work_completed",
    "tae_active_work",
    "tae_peak_active_work",
    "tae_peak_queued_work",
    "tae_work_limit",
    "tae_slice_bytes",
    "tae_peak_cached_metadata_charged_bytes",
    "tae_peak_staging_charged_bytes",
    "tae_gpu_admission_waits",
    "tae_peak_gpu_reservation_admitted_bytes",
    "tae_payload_bytes",
    "result_rows",
    "result_payload_bytes",
    "result_retained_charged_bytes",
    "result_peak_charged_bytes",
    "result_blocked_publications",
    "result_parked_publications",
)


class CampaignError(ValueError):
    pass


class CampaignFailure(CampaignError):
    """A safe, structured campaign failure.

    The exception message is useful to local callers and tests, but callers
    reporting a failure must use ``diagnostic``.  That record deliberately has
    no runner-controlled detail.
    """

    def __init__(
        self,
        category: str,
        sequence: int | None,
        route: str | None,
        attempted: int,
        validated: int,
        status: str,
        detail: str | None = None,
    ):
        self.diagnostic = {
            "category": category,
            "sequence": sequence,
            "route": route,
            "attempted": attempted,
            "validated": validated,
            "status": status,
        }
        super().__init__(detail or f"{category} at sequence {sequence}")


def canonical_json(value: Any) -> str:
    return json.dumps(
        value, sort_keys=True, separators=(",", ":"), ensure_ascii=False,
        allow_nan=False,
    )


def _run_spec(
    sequence: int,
    phase: str,
    route: Mapping[str, str],
    query: int,
    streams: int,
    suite: int,
    repetition: int,
    measured: bool,
    scale_factor: int,
    dataset_sha256: str,
    query_sha256: str,
) -> dict[str, Any]:
    return {
        "sequence": sequence,
        "phase": phase,
        "route": route["id"],
        "backend": route["backend"],
        "scan_mode": route["scan_mode"],
        "query": query,
        "query_sha256": query_sha256,
        "scale_factor": scale_factor,
        "dataset_sha256": dataset_sha256,
        "streams": streams,
        "suite": suite,
        "repetition": repetition,
        "measured": measured,
        "fallback_allowed": False,
    }


def build_schedule(provenance: Mapping[str, Any]) -> list[dict[str, Any]]:
    """Build the fixed serial schedule; route rotation removes order bias."""
    schedule: list[dict[str, Any]] = []

    def append(phase: str, route: Mapping[str, str], query: int, streams: int,
               suite: int, repetition: int, measured: bool,
               scale_factor: int) -> None:
        scale = f"SF{scale_factor}"
        schedule.append(_run_spec(
            len(schedule) + 1, phase, route, query, streams, suite,
            repetition, measured, scale_factor,
            provenance["datasets"][scale],
            provenance["query_sha256"][f"Q{query}"],
        ))

    for scale_factor in SCALE_FACTORS:
        # Stream-count controls are correctness/stress evidence, not
        # performance samples. Performance is exclusively streams=2.
        for streams in (1, 4):
            for query in QUERIES:
                for route in ROUTES:
                    append("stream-validation", route, query, streams, 0, 1, False, scale_factor)

        # Suite zero is one excluded warm-up. Five subsequent suites are measured.
        for suite in range(MEASURED_SUITES + 1):
            for query in QUERIES:
                offset = (scale_factor + suite + query - 1) % len(ROUTES)
                ordered = ROUTES[offset:] + ROUTES[:offset]
                for route in ordered:
                    append(
                        "performance", route, query, PERFORMANCE_STREAMS,
                        suite, 1, suite > 0, scale_factor,
                    )

        # Q9's concurrency-sensitive evidence is independent of the five suites.
        for repetition in range(1, Q9_REPETITIONS + 1):
            offset = (scale_factor + repetition - 1) % len(ROUTES)
            for route in ROUTES[offset:] + ROUTES[:offset]:
                append(
                    "q9-stress", route, 9, PERFORMANCE_STREAMS, 0,
                    repetition, True, scale_factor,
                )
    return schedule


def canonical_query_set_digest(query_digests: Mapping[str, str]) -> str:
    return hashlib.sha256(canonical_json(dict(query_digests)).encode("utf-8")).hexdigest()


def _is_sha256(value: Any) -> bool:
    return (
        isinstance(value, str)
        and len(value) == 64
        and all(character in "0123456789abcdef" for character in value)
    )


def _validate_provenance(provenance: Mapping[str, Any]) -> None:
    if not isinstance(provenance, dict):
        raise CampaignError("invalid campaign provenance object")
    if set(provenance) != set(REQUIRED_PROVENANCE):
        missing = sorted(set(REQUIRED_PROVENANCE) - set(provenance))
        unknown = sorted(set(provenance) - set(REQUIRED_PROVENANCE))
        raise CampaignError(f"invalid campaign provenance; missing={missing}, unknown={unknown}")
    for revision in ("matrixone_revision", "sirius_revision", "sidecar_revision"):
        value = provenance[revision]
        if not isinstance(value, str) or len(value) != 40 or any(c not in "0123456789abcdef" for c in value):
            raise CampaignError(f"invalid campaign provenance: {revision}")
    if not _is_sha256(provenance["sdk_sha256"]):
        raise CampaignError("invalid campaign provenance: sdk_sha256")
    queries = provenance["query_sha256"]
    expected_queries = {f"Q{query}" for query in QUERIES}
    if not isinstance(queries, dict) or set(queries) != expected_queries or not all(_is_sha256(value) for value in queries.values()):
        raise CampaignError("invalid campaign provenance: query_sha256")
    if provenance["query_set_sha256"] != canonical_query_set_digest(queries):
        raise CampaignError("invalid campaign provenance: query_set_sha256")
    datasets = provenance["datasets"]
    if not isinstance(datasets, dict) or set(datasets) != {f"SF{scale}" for scale in SCALE_FACTORS} or not all(_is_sha256(value) for value in datasets.values()):
        raise CampaignError("invalid campaign provenance: datasets")
    hardware = provenance["hardware"]
    if not isinstance(hardware, dict) or set(hardware) != set(HARDWARE_FIELDS):
        raise CampaignError("invalid campaign provenance: hardware")
    if (
        not isinstance(hardware["cpu"], str) or not hardware["cpu"]
        or not isinstance(hardware["gpu"], str) or not hardware["gpu"]
        or type(hardware["host_memory_bytes"]) is not int or hardware["host_memory_bytes"] <= 0
        or type(hardware["gpu_memory_bytes"]) is not int or hardware["gpu_memory_bytes"] <= 0
    ):
        raise CampaignError("invalid campaign provenance: hardware")
    config = provenance["config"]
    if not isinstance(config, dict) or set(config) != set(CONFIG_FIELDS):
        raise CampaignError("invalid campaign provenance: config")
    if not _is_sha256(config["sha256"]) or any(
        not isinstance(config[field], str) or not config[field]
        for field in ("cuda_version", "driver_version")
    ):
        raise CampaignError("invalid campaign provenance: config")


def build_campaign(
    provenance: Mapping[str, Any],
    float_tolerances: Mapping[str, Mapping[str, float]] | None = None,
) -> dict[str, Any]:
    _validate_provenance(provenance)
    tolerances = dict(float_tolerances or {})
    for query, tolerance in tolerances.items():
        if query not in {f"Q{number}" for number in QUERIES}:
            raise CampaignError(f"invalid tolerance query {query}")
        if set(tolerance) != {"absolute", "relative"}:
            raise CampaignError(f"invalid tolerance for {query}")
        if any(
            not isinstance(tolerance[field], (int, float))
            or not math.isfinite(tolerance[field])
            or tolerance[field] < 0
            for field in ("absolute", "relative")
        ):
            raise CampaignError(f"negative tolerance for {query}")
    return {
        "schema_version": SCHEMA_VERSION,
        "queries": list(QUERIES),
        "scale_factors": list(SCALE_FACTORS),
        "routes": list(ROUTES),
        "streams": list(STREAMS),
        "performance_streams": PERFORMANCE_STREAMS,
        "warmup_suites": 1,
        "measured_suites": MEASURED_SUITES,
        "q9_repetitions": Q9_REPETITIONS,
        "gpu_concurrency": 1,
        "fallback_allowed": False,
        "result_policy": {
            "default": "typed-exact",
            "float_tolerances": tolerances,
            "decimal": "typed-exact",
            "schema": "exact",
        },
        "performance_gates": {
            "embedded_mo_to_embedded_tae": 2.0,
            "embedded_tae_to_flight_tae": 1.0,
            "embedded_mo_to_flight_mo": 1.0,
        },
        "required_execution_stats": list(REQUIRED_EXECUTION_STATS),
        "provenance": json.loads(canonical_json(provenance)),
        "schedule": build_schedule(provenance),
    }


Executor = Callable[[Mapping[str, Any]], Mapping[str, Any]]


def _oracle_cell(spec: Mapping[str, Any]) -> tuple[Any, ...]:
    return (
        spec["scale_factor"], spec["phase"], spec["streams"], spec["suite"],
        spec["repetition"], spec["query"],
    )


class IncrementalValidator:
    """Validate one serial campaign while retaining seen route results."""

    def __init__(self, campaign: Mapping[str, Any]):
        self.schedule = tuple(campaign["schedule"])
        self.required_stats = campaign["required_execution_stats"]
        self.tolerances = campaign["result_policy"]["float_tolerances"]
        self.attempted = 0
        self.validated = 0
        self._next_index = 0
        self._cells: dict[
            tuple[Any, ...],
            dict[str, tuple[Mapping[str, Any], Mapping[str, Any]]],
        ] = {}

    def start(self) -> Mapping[str, Any]:
        """Select the trusted next spec and count its attempt before execution."""
        self.attempted += 1
        if self._next_index >= len(self.schedule):
            self._fail(
                "incomplete",
                None,
                "incomplete campaign: received a run after the schedule ended",
                status="incomplete",
            )
        return self.schedule[self._next_index]

    def _fail(
        self,
        category: str,
        expected: Mapping[str, Any] | None,
        detail: str,
        *,
        status: str = "invalid",
    ) -> None:
        raise CampaignFailure(
            category,
            None if expected is None else expected.get("sequence"),
            None if expected is None else expected.get("route"),
            self.attempted,
            self.validated,
            status,
            detail,
        )

    def accept(self, record: Mapping[str, Any]) -> None:
        """Accept one record and compare any oracle pair that is now ready."""
        expected = self.schedule[self._next_index]
        if not isinstance(record, Mapping):
            self._fail("malformed-output", expected, "runner result is not an object")
        try:
            record_spec = {key: record.get(key) for key in expected}
        except Exception:
            self._fail("malformed-output", expected, "runner result is not an object")
        if record_spec != expected:
            self._fail(
                "order",
                expected,
                f"campaign order/spec mismatch at sequence {expected['sequence']}",
            )
        output = record.get("output")
        if not isinstance(output, dict):
            self._fail("malformed-output", expected, "runner output is not an object")
        try:
            _validate_output(expected, output, self.required_stats)
        except CampaignError as error:
            self._fail("invalid-output", expected, str(error))
        except Exception:
            self._fail("malformed-output", expected, "runner output is malformed")

        oracle_cell = _oracle_cell(expected)
        group = self._cells.setdefault(oracle_cell, {})
        route = expected["route"]
        if route in group:
            self._fail(
                "duplicate",
                expected,
                f"duplicate campaign cell at sequence {expected['sequence']}",
            )
        group[route] = (expected, output)
        self._next_index += 1

        if route == "mo-native":
            self.validated += 1
            for pending_route, (pending_expected, pending_output) in group.items():
                if pending_route == "mo-native":
                    continue
                self._compare_or_fail(
                    pending_expected, output, pending_output, failure_expected=expected
                )
                self.validated += 1
            return

        native = group.get("mo-native")
        if native is None:
            return
        self._compare_or_fail(expected, native[1], output)
        self.validated += 1

    def _compare_or_fail(
        self,
        comparison_expected: Mapping[str, Any],
        native: Mapping[str, Any],
        actual: Mapping[str, Any],
        failure_expected: Mapping[str, Any] | None = None,
    ) -> None:
        try:
            _compare_results(
                native["result"],
                actual["result"],
                self.tolerances.get(f"Q{comparison_expected['query']}"),
            )
        except CampaignError as error:
            self._fail(
                "result-mismatch", failure_expected or comparison_expected, str(error)
            )
        except Exception:
            self._fail(
                "result-mismatch", failure_expected or comparison_expected,
                "result comparison failed",
            )

    def finish(self) -> None:
        if self._next_index != len(self.schedule):
            expected = (
                self.schedule[self._next_index]
                if self._next_index < len(self.schedule)
                else None
            )
            self._fail(
                "incomplete",
                expected,
                f"incomplete campaign: expected {len(self.schedule)} runs, "
                f"got {self._next_index}",
                status="incomplete",
            )
        for group in self._cells.values():
            if "mo-native" not in group:
                expected, _ = next(iter(group.values()))
                self._fail(
                    "missing-native",
                    expected,
                    f"missing native result oracle for sequence {expected['sequence']}",
                    status="incomplete",
                )


def execute_campaign(campaign: Mapping[str, Any], executor: Executor) -> list[dict[str, Any]]:
    validator = IncrementalValidator(campaign)
    runs: list[dict[str, Any]] = []
    for _ in campaign["schedule"]:
        spec = validator.start()
        try:
            # The runner receives a private copy.  Diagnostics and records use
            # the trusted schedule object, even if a runner mutates its input.
            raw_output = executor(copy.deepcopy(spec))
        except Exception:
            raise CampaignFailure(
                "runner-exception",
                spec["sequence"],
                spec["route"],
                validator.attempted,
                validator.validated,
                "invalid",
                "runner exception",
            ) from None
        if not isinstance(raw_output, Mapping):
            validator._fail("malformed-output", spec, "runner result is not an object")
        try:
            output = dict(raw_output)
        except Exception:
            validator._fail("malformed-output", spec, "runner result is not an object")
        record = copy.deepcopy(spec)
        record["output"] = output
        validator.accept(record)
        runs.append(record)
    validator.finish()
    return runs


class SubprocessExecutor:
    def __init__(self, command: Sequence[str], timeout_seconds: float):
        if not command:
            raise CampaignError("runner command is required")
        if not math.isfinite(timeout_seconds) or timeout_seconds <= 0:
            raise CampaignError("runner timeout must be positive and finite")
        self.command = tuple(command)
        self.timeout_seconds = timeout_seconds
        self.poisoned = False

    def __call__(self, spec: Mapping[str, Any]) -> Mapping[str, Any]:
        with _SUBPROCESS_EXECUTOR_LOCK:
            return self._call_exclusive(spec)

    def _call_exclusive(self, spec: Mapping[str, Any]) -> Mapping[str, Any]:
        if self.poisoned:
            raise CampaignError("campaign runner cleanup owner is poisoned")
        previous_subreaper = _enter_exclusive_subreaper()
        environment = os.environ.copy()
        environment["MO_SIRIUS_CAMPAIGN_RUN"] = canonical_json(spec)
        process: subprocess.Popen[str] | None = None
        try:
            process = subprocess.Popen(
                self.command,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                env=environment,
                start_new_session=True,
            )
            try:
                stdout, stderr = process.communicate(timeout=self.timeout_seconds)
            except subprocess.TimeoutExpired as error:
                _cleanup_owned_processes(process, close_pipes=True)
                process = None
                raise CampaignError(
                    f"runner timed out for sequence {spec['sequence']}"
                ) from error
            except BaseException:
                _cleanup_owned_processes(process, close_pipes=True)
                process = None
                raise

            # communicate reaped the direct runner. A child can nevertheless
            # detach with setsid and close its inherited pipes; subreaper
            # adoption makes every such survivor our direct child here.
            returncode = process.returncode
            _cleanup_owned_processes(process, close_pipes=False)
            process = None
            if returncode != 0:
                raise CampaignError(
                    f"runner failed for sequence {spec['sequence']}: exit {returncode}"
                )
            try:
                result = json.loads(stdout)
            except json.JSONDecodeError:
                raise CampaignError(
                    f"runner returned invalid JSON for sequence {spec['sequence']}"
                )
            if not isinstance(result, dict):
                raise CampaignError(
                    f"runner result for sequence {spec['sequence']} is not an object"
                )
            return result
        finally:
            if process is not None:
                try:
                    _cleanup_owned_processes(process, close_pipes=True)
                except BaseException:
                    self.poisoned = True
                    raise
            children = _direct_child_pids()
            if children:
                self.poisoned = True
                raise CampaignError(
                    f"campaign runner cleanup left owned children: {sorted(children)}"
                )
            _set_child_subreaper(previous_subreaper)


def _libc_prctl() -> Any:
    libc = ctypes.CDLL(None, use_errno=True)
    if not hasattr(libc, "prctl"):
        raise CampaignError("campaign runner requires Linux prctl")
    return libc.prctl


def _get_child_subreaper() -> bool:
    value = ctypes.c_int()
    if _libc_prctl()(_PR_GET_CHILD_SUBREAPER, ctypes.byref(value), 0, 0, 0) != 0:
        error = ctypes.get_errno()
        raise CampaignError(f"read child-subreaper state: {os.strerror(error)}")
    return bool(value.value)


def _set_child_subreaper(enabled: bool) -> None:
    if _libc_prctl()(_PR_SET_CHILD_SUBREAPER, int(enabled), 0, 0, 0) != 0:
        error = ctypes.get_errno()
        raise CampaignError(f"set child-subreaper state: {os.strerror(error)}")


def _direct_child_pids() -> set[int]:
    children: set[int] = set()
    task_root = Path(f"/proc/{os.getpid()}/task")
    try:
        tasks = tuple(task_root.iterdir())
    except OSError as error:
        raise CampaignError(f"enumerate campaign tasks: {error}") from error
    for task in tasks:
        try:
            raw = (task / "children").read_text(encoding="ascii").strip()
        except FileNotFoundError:
            continue
        except OSError as error:
            raise CampaignError(f"enumerate campaign children: {error}") from error
        if raw:
            children.update(int(value) for value in raw.split())
    return children


def _enter_exclusive_subreaper() -> bool:
    if sys.platform != "linux" or not hasattr(os, "pidfd_open") or not hasattr(signal, "pidfd_send_signal"):
        raise CampaignError("campaign runner ownership requires Linux prctl, procfs, and pidfds")
    existing = _direct_child_pids()
    if existing:
        raise CampaignError(
            f"campaign runner requires exclusive subprocess ownership; existing children={sorted(existing)}"
        )
    previous = _get_child_subreaper()
    _set_child_subreaper(True)
    return previous


def _remaining_cleanup_seconds(deadline: float) -> float:
    remaining = deadline - time.monotonic()
    if remaining <= 0:
        raise CampaignError("campaign runner cleanup deadline exceeded")
    return remaining


def _kill_original_process_group(process: subprocess.Popen[str]) -> None:
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except ProcessLookupError:
        pass


def _close_process_pipes(process: subprocess.Popen[str]) -> None:
    for pipe in (process.stdout, process.stderr):
        if pipe is not None:
            pipe.close()


def _kill_and_reap_adopted_children(deadline: float) -> None:
    while True:
        children = _direct_child_pids()
        if not children:
            return
        descriptors: dict[int, int] = {}
        try:
            for pid in children:
                try:
                    descriptor = os.pidfd_open(pid)
                except ProcessLookupError:
                    continue
                descriptors[pid] = descriptor
                try:
                    signal.pidfd_send_signal(descriptor, signal.SIGKILL)
                except ProcessLookupError:
                    pass
            poller = select.poll()
            for descriptor in descriptors.values():
                poller.register(descriptor, select.POLLIN)
            pending = set(descriptors.values())
            while pending:
                timeout_ms = max(1, math.ceil(_remaining_cleanup_seconds(deadline) * 1000))
                events = poller.poll(timeout_ms)
                if not events:
                    raise CampaignError("campaign runner cleanup deadline exceeded")
                pending.difference_update(descriptor for descriptor, _ in events)
        finally:
            for descriptor in descriptors.values():
                os.close(descriptor)
        for pid in children:
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass


def _cleanup_owned_processes(process: subprocess.Popen[str], close_pipes: bool) -> None:
    deadline = time.monotonic() + RUNNER_CLEANUP_TIMEOUT_SECONDS
    _kill_original_process_group(process)
    if close_pipes:
        _close_process_pipes(process)
    if process.poll() is None:
        try:
            process.wait(timeout=_remaining_cleanup_seconds(deadline))
        except subprocess.TimeoutExpired as error:
            raise CampaignError("direct campaign runner did not terminate during cleanup") from error
    _kill_and_reap_adopted_children(deadline)


def _sql_type_base(value: str) -> str:
    return value.strip().lower().split("(", 1)[0].strip()


def _validated_result_schema(schema: Any, sequence: int | None = None) -> list[dict[str, str]]:
    location = "" if sequence is None else f" at sequence {sequence}"
    if not isinstance(schema, list) or not schema:
        raise CampaignError(f"invalid result schema{location}")
    validated: list[dict[str, str]] = []
    for column in schema:
        if not isinstance(column, dict) or set(column) != RESULT_SCHEMA_FIELDS:
            raise CampaignError(f"invalid result schema{location}")
        name, sql_type = column["name"], column["type"]
        if (
            not isinstance(name, str)
            or not name
            or "\x00" in name
            or not isinstance(sql_type, str)
            or not sql_type
            or "\x00" in sql_type
        ):
            raise CampaignError(f"invalid result schema{location}")
        validated.append({"name": name, "type": sql_type})
    return validated


def _validate_typed_result(result: Mapping[str, Any], sequence: int) -> None:
    schema = _validated_result_schema(result.get("schema"), sequence)
    rows = result.get("rows")
    if not isinstance(rows, list) or not rows:
        raise CampaignError(f"canonical TPCH result is empty at sequence {sequence}")
    for row_index, row in enumerate(rows):
        if not isinstance(row, list) or len(row) != len(schema):
            raise CampaignError(f"invalid result row at sequence {sequence}/{row_index}")
        for column_index, (column, cell) in enumerate(zip(schema, row)):
            if (
                not isinstance(cell, dict)
                or set(cell) != RESULT_CELL_FIELDS
                or cell["type"] != column["type"]
                or (
                    cell["value"] is not None
                    and type(cell["value"]) not in (bool, int, float, str)
                )
            ):
                raise CampaignError(
                    f"invalid typed result cell at sequence {sequence}/{row_index}/{column_index}"
                )
            value = cell["value"]
            type_base = _sql_type_base(column["type"])
            if type_base in ("decimal", "numeric") and value is not None and not isinstance(value, str):
                raise CampaignError(
                    f"inexact decimal result encoding at sequence {sequence}/{row_index}/{column_index}"
                )
            if type_base in INTEGER_SQL_RANGES and value is not None:
                minimum, maximum = INTEGER_SQL_RANGES[type_base]
                if type(value) is not int or value < minimum or value > maximum:
                    raise CampaignError(
                        f"inexact integer result encoding at sequence {sequence}/{row_index}/{column_index}"
                    )
            if (
                type_base in FLOAT_SQL_TYPES
                and value is not None
                and (type(value) not in (int, float) or not math.isfinite(value))
            ):
                raise CampaignError(
                    f"invalid floating result encoding at sequence {sequence}/{row_index}/{column_index}"
                )


def _result_bytes(result: Mapping[str, Any]) -> bytes:
    # Unknown result fields are not part of equality or the published digest.
    return canonical_json({"schema": result["schema"], "rows": result["rows"]}).encode("utf-8")


def _validate_output(spec: Mapping[str, Any], output: Mapping[str, Any], required_stats: Iterable[str]) -> None:
    evidence = output.get("evidence")
    expected_evidence = {
        "sequence": spec["sequence"],
        "scale_factor": spec["scale_factor"],
        "dataset_sha256": spec["dataset_sha256"],
        "query": spec["query"],
        "query_sha256": spec["query_sha256"],
        "gpu_streams": spec["streams"],
    }
    if not isinstance(evidence, dict) or evidence != expected_evidence:
        raise CampaignError(f"runner identity evidence mismatch at sequence {spec['sequence']}")
    if output.get("backend") != spec["backend"] or output.get("scan_mode") != spec["scan_mode"]:
        raise CampaignError(f"route evidence mismatch at sequence {spec['sequence']}")
    if output.get("fallback") is not False:
        raise CampaignError(f"fallback observed at sequence {spec['sequence']}")
    wall = output.get("wall_seconds")
    first_row = output.get("first_row_seconds")
    cpu = output.get("cpu_seconds")
    if not isinstance(wall, (int, float)) or not math.isfinite(wall) or wall <= 0:
        raise CampaignError(f"invalid wall time at sequence {spec['sequence']}")
    if (
        not isinstance(first_row, (int, float))
        or not math.isfinite(first_row)
        or first_row < 0
        or first_row > wall
    ):
        raise CampaignError(f"invalid first-row time at sequence {spec['sequence']}")
    if not isinstance(cpu, (int, float)) or not math.isfinite(cpu) or cpu < 0:
        raise CampaignError(f"invalid CPU time at sequence {spec['sequence']}")
    memory_peaks = output.get("memory_peaks")
    if not isinstance(memory_peaks, dict) or set(memory_peaks) != {
        "go_bytes", "native_host_bytes", "pinned_host_bytes", "gpu_bytes",
    }:
        raise CampaignError(f"invalid memory peak evidence at sequence {spec['sequence']}")
    if any(type(value) is not int or value < 0 for value in memory_peaks.values()):
        raise CampaignError(f"invalid memory peak evidence at sequence {spec['sequence']}")
    if output.get("cancellation_origin") != "none":
        raise CampaignError(f"unexpected cancellation at sequence {spec['sequence']}")
    expected_health = "not-applicable" if spec["route"] == "mo-native" else "accepting"
    if output.get("terminal_health") != expected_health:
        raise CampaignError(f"terminal health mismatch at sequence {spec['sequence']}")
    result = output.get("result")
    if not isinstance(result, dict) or "schema" not in result or "rows" not in result:
        raise CampaignError(f"missing typed result at sequence {spec['sequence']}")
    _validate_typed_result(result, spec["sequence"])
    try:
        _result_bytes(result)
    except (TypeError, ValueError):
        raise CampaignError(f"invalid result encoding at sequence {spec['sequence']}") from None
    if spec["route"] == "mo-native":
        return
    stats = output.get("execution_stats")
    if not isinstance(stats, dict):
        raise CampaignError(f"missing execution stats at sequence {spec['sequence']}")
    missing = [field for field in required_stats if field not in stats]
    if missing:
        raise CampaignError(
            f"incomplete execution stats at sequence {spec['sequence']}: {', '.join(missing)}"
        )
    for field in required_stats:
        if type(stats[field]) is not int or stats[field] < 0:
            raise CampaignError(f"invalid execution stat {field} at sequence {spec['sequence']}")
    started = stats["gpu_tasks_started"]
    completed = stats["gpu_tasks_completed"]
    expected_source = 1 if spec["scan_mode"] == "mo" else 2
    if (
        stats["terminal"] != 1
        or stats["terminal_status"] != 0
        or stats["fatal"] != 0
        or stats["source_mask"] != expected_source
        or started <= 0
        or completed != started
    ):
        raise CampaignError(f"missing successful GPU execution evidence at sequence {spec['sequence']}")
    rows = result["rows"]
    if not isinstance(rows, list) or stats["result_rows"] != len(rows):
        raise CampaignError(f"result-row execution evidence mismatch at sequence {spec['sequence']}")
    if (
        stats["result_rows"] <= 0
        or stats["result_payload_bytes"] <= 0
        or stats["result_peak_charged_bytes"] <= 0
        or stats["result_peak_charged_bytes"] > RESULT_WINDOW_BYTES
        or stats["result_retained_charged_bytes"] != 0
        or stats["result_parked_publications"] != 0
    ):
        raise CampaignError(f"invalid result retention evidence at sequence {spec['sequence']}")
    if spec["scan_mode"] == "mo":
        if (
            stats["mo_input_units"] <= 0
            or stats["mo_input_peak_charged_bytes"] <= 0
            or stats["mo_input_retained_charged_bytes"] != 0
            or any(stats[field] != 0 for field in (
                "tae_requests", "tae_work_issued", "tae_work_completed",
                "tae_active_work", "tae_peak_active_work", "tae_peak_queued_work",
                "tae_work_limit", "tae_slice_bytes",
                "tae_peak_cached_metadata_charged_bytes",
                "tae_peak_staging_charged_bytes", "tae_gpu_admission_waits",
                "tae_peak_gpu_reservation_admitted_bytes", "tae_payload_bytes",
            ))
        ):
            raise CampaignError(f"MO source execution evidence mismatch at sequence {spec['sequence']}")
    else:
        expected_limit = max(2, 2 * spec["streams"])
        maximum_slice = min(
            TAE_STAGING_SLICE_BYTES,
            TAE_HOST_WINDOW_BYTES // expected_limit,
        )
        if (
            stats["mo_input_units"] != 0
            or stats["mo_input_retained_charged_bytes"] != 0
            or stats["mo_input_peak_charged_bytes"] != 0
            or stats["mo_input_blocked_acquires"] != 0
            or stats["tae_requests"] <= 0
            or stats["tae_work_issued"] <= 0
            or stats["tae_work_completed"] != stats["tae_work_issued"]
            or stats["tae_active_work"] != 0
            or stats["tae_work_limit"] != expected_limit
            or stats["tae_peak_active_work"] < 1
            or stats["tae_peak_active_work"] > expected_limit
            or stats["tae_slice_bytes"] <= 0
            or stats["tae_slice_bytes"] > maximum_slice
            or stats["tae_peak_cached_metadata_charged_bytes"] <= 0
            or stats["tae_peak_cached_metadata_charged_bytes"] > TAE_METADATA_CACHE_BYTES
            or stats["tae_peak_staging_charged_bytes"] <= 0
            or stats["tae_peak_staging_charged_bytes"] > TAE_HOST_WINDOW_BYTES
            or stats["tae_peak_gpu_reservation_admitted_bytes"] <= 0
            or stats["tae_payload_bytes"] <= 0
        ):
            raise CampaignError(f"TAE source execution evidence mismatch at sequence {spec['sequence']}")


def _compare_typed(expected: Any, actual: Any, tolerance: Mapping[str, float] | None, path: str = "result") -> None:
    if type(expected) is not type(actual):  # bool must not compare equal to int.
        raise CampaignError(f"typed result mismatch at {path}")
    if isinstance(expected, float):
        if not math.isfinite(expected) or not math.isfinite(actual):
            raise CampaignError(f"non-finite result at {path}")
        if tolerance is None:
            if expected != actual:
                raise CampaignError(f"exact floating result mismatch at {path}")
            return
        if not math.isclose(
            expected,
            actual,
            rel_tol=tolerance["relative"],
            abs_tol=tolerance["absolute"],
        ):
            raise CampaignError(f"floating result mismatch at {path}")
        return
    if isinstance(expected, list):
        if len(expected) != len(actual):
            raise CampaignError(f"result length mismatch at {path}")
        for index, (left, right) in enumerate(zip(expected, actual)):
            _compare_typed(left, right, tolerance, f"{path}[{index}]")
        return
    if isinstance(expected, dict):
        if expected.keys() != actual.keys():
            raise CampaignError(f"result field mismatch at {path}")
        for key in expected:
            _compare_typed(expected[key], actual[key], tolerance, f"{path}.{key}")
        return
    if expected != actual:
        raise CampaignError(f"exact result mismatch at {path}")


def _compare_results(
    expected: Mapping[str, Any],
    actual: Mapping[str, Any],
    tolerance: Mapping[str, float] | None,
) -> None:
    _validate_typed_result(expected, 0)
    _validate_typed_result(actual, 0)
    expected_schema = _validated_result_schema(expected.get("schema"))
    actual_schema = _validated_result_schema(actual.get("schema"))
    _compare_typed(expected_schema, actual_schema, None, "result.schema")
    expected_rows, actual_rows = expected.get("rows"), actual.get("rows")
    if not isinstance(expected_rows, list) or not isinstance(actual_rows, list):
        raise CampaignError("invalid result rows")
    if len(expected_rows) != len(actual_rows):
        raise CampaignError("result length mismatch at result.rows")
    for row_index, (expected_row, actual_row) in enumerate(zip(expected_rows, actual_rows)):
        if not isinstance(expected_row, list) or not isinstance(actual_row, list):
            raise CampaignError(f"invalid result row at result.rows[{row_index}]")
        if len(expected_row) != len(expected_schema) or len(actual_row) != len(actual_schema):
            raise CampaignError(f"result length mismatch at result.rows[{row_index}]")
        for column_index, (column, expected_cell, actual_cell) in enumerate(
            zip(expected_schema, expected_row, actual_row)
        ):
            path = f"result.rows[{row_index}][{column_index}]"
            if not isinstance(expected_cell, dict) or not isinstance(actual_cell, dict):
                raise CampaignError(f"invalid typed result cell at {path}")
            _compare_typed(expected_cell.get("type"), actual_cell.get("type"), None, f"{path}.type")
            cell_tolerance = (
                tolerance
                if _sql_type_base(column["type"]) in FLOAT_SQL_TYPES
                else None
            )
            _compare_typed(
                expected_cell.get("value"), actual_cell.get("value"),
                cell_tolerance, f"{path}.value",
            )


def validate_runs(campaign: Mapping[str, Any], runs: Sequence[Mapping[str, Any]]) -> None:
    validator = IncrementalValidator(campaign)
    for record in runs:
        validator.start()
        validator.accept(record)
    validator.finish()


def _median(values: Iterable[float]) -> float:
    materialized = list(values)
    if not materialized:
        raise CampaignError("missing measured timing samples")
    return float(statistics.median(materialized))


def summarize(campaign: Mapping[str, Any], runs: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    validate_runs(campaign, runs)
    return _summarize_validated(campaign, runs)


def _summarize_validated(campaign: Mapping[str, Any], runs: Sequence[Mapping[str, Any]]) -> dict[str, Any]:
    routes = [route["id"] for route in ROUTES]
    query_samples: dict[tuple[int, str, int], list[float]] = {}
    suite_samples: dict[tuple[int, str, int], list[float]] = {}
    q9_samples: dict[tuple[int, str], list[float]] = {}
    for record in runs:
        wall = float(record["output"]["wall_seconds"])
        route = record["route"]
        scale = record["scale_factor"]
        if record["phase"] == "performance" and record["measured"]:
            query_samples.setdefault((scale, route, record["query"]), []).append(wall)
            suite_samples.setdefault((scale, route, record["suite"]), []).append(wall)
        elif record["phase"] == "q9-stress":
            q9_samples.setdefault((scale, route), []).append(wall)

    gates = campaign["performance_gates"]
    checks: list[dict[str, Any]] = []

    def ratio_gate(name: str, numerator: float, denominator: float, limit: float) -> None:
        if denominator <= 0:
            raise CampaignError(f"invalid gate denominator for {name}")
        ratio = numerator / denominator
        checks.append({"name": name, "ratio": ratio, "limit": limit, "passed": ratio <= limit})

    scales: dict[str, Any] = {}
    for scale in SCALE_FACTORS:
        summary_routes: dict[str, Any] = {}
        for route in routes:
            query_medians = {
                f"Q{query}": _median(query_samples.get((scale, route, query), []))
                for query in QUERIES
            }
            suite_totals = [
                sum(suite_samples.get((scale, route, suite), []))
                for suite in range(1, MEASURED_SUITES + 1)
            ]
            if any(len(suite_samples.get((scale, route, suite), [])) != len(QUERIES)
                   for suite in range(1, MEASURED_SUITES + 1)):
                raise CampaignError(f"incomplete measured suite for SF{scale}/{route}")
            summary_routes[route] = {
                "query_medians": query_medians,
                "sum_query_medians": sum(query_medians.values()),
                "median_full_suite": _median(suite_totals),
                "q9_stress_median": _median(q9_samples.get((scale, route), [])),
            }
        first_gate = len(checks)
        for metric in ("sum_query_medians", "median_full_suite", "q9_stress_median"):
            ratio_gate(
                f"SF{scale}/embedded-mo/{metric}/embedded-tae",
                summary_routes["embedded-mo"][metric],
                summary_routes["embedded-tae"][metric],
                gates["embedded_mo_to_embedded_tae"],
            )
            ratio_gate(
                f"SF{scale}/embedded-tae/{metric}/flight-tae",
                summary_routes["embedded-tae"][metric],
                summary_routes["flight-tae"][metric],
                gates["embedded_tae_to_flight_tae"],
            )
            ratio_gate(
                f"SF{scale}/embedded-mo/{metric}/flight-mo",
                summary_routes["embedded-mo"][metric],
                summary_routes["flight-mo"][metric],
                gates["embedded_mo_to_flight_mo"],
            )
        scale_checks = checks[first_gate:]
        scales[f"SF{scale}"] = {
            "routes": summary_routes,
            "gates": scale_checks,
            "passed": all(check["passed"] for check in scale_checks),
        }
    return {
        "schema_version": SCHEMA_VERSION,
        "scales": scales,
        "gates": checks,
        "passed": all(check["passed"] for check in checks),
    }


def _format_seconds(value: float) -> str:
    return f"{value:.6f}"


def summary_csv(summary: Mapping[str, Any]) -> str:
    target = io.StringIO(newline="")
    headings = ["scale_factor", "route", "backend", "scan_mode"] + [f"Q{q}" for q in QUERIES] + [
        "sum_query_medians", "median_full_suite", "q9_stress_median", "gates_passed",
    ]
    writer = csv.DictWriter(target, fieldnames=headings, lineterminator="\n")
    writer.writeheader()
    by_id = {route["id"]: route for route in ROUTES}
    for scale in SCALE_FACTORS:
        for route in by_id:
            values = summary["scales"][f"SF{scale}"]["routes"][route]
            row: dict[str, Any] = {
                "scale_factor": scale,
                "route": route,
                "backend": by_id[route]["backend"],
                "scan_mode": by_id[route]["scan_mode"],
                "sum_query_medians": _format_seconds(values["sum_query_medians"]),
                "median_full_suite": _format_seconds(values["median_full_suite"]),
                "q9_stress_median": _format_seconds(values["q9_stress_median"]),
                "gates_passed": str(summary["scales"][f"SF{scale}"]["passed"]).lower(),
            }
            row.update({query: _format_seconds(value) for query, value in values["query_medians"].items()})
            writer.writerow(row)
    return target.getvalue()


def summary_markdown(summary: Mapping[str, Any]) -> str:
    columns = ["Route"] + [f"Q{query}" for query in QUERIES] + [
        "Sum of medians", "Median full suite", "Q9 x10 median",
    ]
    lines = ["# Sirius TPCH parity summary"]
    for scale in SCALE_FACTORS:
        lines.extend(["", f"## SF{scale}", "", " | ".join(columns), " | ".join(["---"] * len(columns))])
        for route in (item["id"] for item in ROUTES):
            values = summary["scales"][f"SF{scale}"]["routes"][route]
            line = [route]
            line.extend(_format_seconds(values["query_medians"][f"Q{query}"]) for query in QUERIES)
            line.extend([
                _format_seconds(values["sum_query_medians"]),
                _format_seconds(values["median_full_suite"]),
                _format_seconds(values["q9_stress_median"]),
            ])
            lines.append(" | ".join(line))
        lines.extend(["", f"### SF{scale} relative gates", ""])
        for gate in summary["scales"][f"SF{scale}"]["gates"]:
            state = "PASS" if gate["passed"] else "FAIL"
            lines.append(
                f"- {state}: {gate['name']} = {gate['ratio']:.6f}, limit {gate['limit']:.6f}"
            )
    lines.extend(["", f"Overall: {'PASS' if summary['passed'] else 'FAIL'}", ""])
    return "\n".join(lines)


def write_artifacts(
    campaign: Mapping[str, Any],
    runs: Sequence[Mapping[str, Any]],
    output_directory: Path,
) -> dict[str, Any]:
    _ensure_output_directory_available(output_directory)
    validate_runs(campaign, runs)
    return _write_validated_artifacts(campaign, runs, output_directory)


def _write_validated_artifacts(
    campaign: Mapping[str, Any],
    runs: Sequence[Mapping[str, Any]],
    output_directory: Path,
) -> dict[str, Any]:
    _ensure_output_directory_available(output_directory)
    try:
        summary = _summarize_validated(campaign, runs)
        output_directory.mkdir(parents=True, exist_ok=True)
        (output_directory / "campaign.json").write_text(
            canonical_json(campaign) + "\n", encoding="utf-8"
        )
        raw = "".join(canonical_json(_artifact_run(campaign, record)) + "\n" for record in runs)
        (output_directory / "runs.jsonl").write_text(raw, encoding="utf-8")
        (output_directory / "summary.csv").write_text(summary_csv(summary), encoding="utf-8")
        (output_directory / "summary.md").write_text(summary_markdown(summary), encoding="utf-8")
    except CampaignFailure:
        raise
    except (KeyError, OSError, TypeError, ValueError):
        raise CampaignFailure(
            "artifact-write", None, None, len(runs), len(runs), "invalid", "artifact write failed"
        ) from None
    return summary


def _ensure_output_directory_available(output_directory: Path) -> None:
    try:
        if not output_directory.exists():
            return
        if not output_directory.is_dir():
            raise CampaignFailure(
                "output-directory", None, None, 0, 0, "invalid", "output path is not a directory"
            )
        if next(output_directory.iterdir(), None) is not None:
            raise CampaignFailure(
                "output-directory", None, None, 0, 0, "invalid", "output directory is not empty"
            )
    except CampaignFailure:
        raise
    except OSError:
        raise CampaignFailure(
            "output-directory", None, None, 0, 0, "invalid", "output directory is unavailable"
        ) from None


def write_failure(
    output_directory: Path,
    failure: CampaignFailure,
    *,
    allow_partial: bool = False,
) -> None:
    """Append an internal diagnostic; only this run's owner may allow partial artifacts."""
    if not allow_partial:
        _ensure_output_directory_available(output_directory)
    output_directory.mkdir(parents=True, exist_ok=True)
    with (output_directory / "failure.json").open("x", encoding="utf-8") as destination:
        destination.write(canonical_json(failure.diagnostic) + "\n")


def _report_failure(
    failure: CampaignFailure, output_directory: Path, *, allow_partial: bool = False,
) -> int:
    if failure.diagnostic["category"] == "output-directory":
        artifact_status = "not-written"
    else:
        try:
            write_failure(output_directory, failure, allow_partial=allow_partial)
        except Exception:
            artifact_status = "write-failed"
        else:
            artifact_status = "written"
    print(
        "sirius parity campaign failed: "
        f"{canonical_json(failure.diagnostic)} "
        f"artifact_status={artifact_status}",
        file=sys.stderr,
    )
    return 1


def _artifact_run(campaign: Mapping[str, Any], record: Mapping[str, Any]) -> dict[str, Any]:
    """Return the strict, redacted runs.jsonl record.

    Typed rows remain available to validate_runs in memory but are never
    persisted. Unknown runner fields are intentionally dropped so credentials,
    object paths, query text, or other deployment-local material cannot leak.
    """
    output = record["output"]
    result = output["result"]
    result_bytes = _result_bytes(result)
    safe_output: dict[str, Any] = {
        "evidence": dict(output["evidence"]),
        "backend": output["backend"],
        "scan_mode": output["scan_mode"],
        "fallback": output["fallback"],
        "first_row_seconds": output["first_row_seconds"],
        "wall_seconds": output["wall_seconds"],
        "cpu_seconds": output["cpu_seconds"],
        "memory_peaks": dict(output["memory_peaks"]),
        "cancellation_origin": output["cancellation_origin"],
        "terminal_health": output["terminal_health"],
        "result": {
            "schema": _validated_result_schema(result["schema"]),
            "row_count": len(result["rows"]),
            "sha256": hashlib.sha256(result_bytes).hexdigest(),
        },
    }
    if record["route"] != "mo-native":
        stats = output["execution_stats"]
        safe_output["execution_stats"] = {
            field: stats[field] for field in campaign["required_execution_stats"]
        }
    safe = {key: record[key] for key in campaign["schedule"][0]}
    safe["output"] = safe_output
    return safe


def main(argv: Sequence[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--spec", type=Path, required=True, help="JSON object containing provenance and optional float_tolerances")
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--timeout-seconds", type=float, default=3600)
    parser.add_argument("runner", nargs=argparse.REMAINDER, help="runner command after --")
    arguments = parser.parse_args(argv)
    runner = arguments.runner
    if runner and runner[0] == "--":
        runner = runner[1:]
    try:
        # Reject stale output before constructing or invoking a runner.
        _ensure_output_directory_available(arguments.output)
        spec = json.loads(arguments.spec.read_text(encoding="utf-8"))
        if spec.get("schema_version", 1) == 2:
            from sirius_campaign_v2 import main_from_legacy
            return main_from_legacy(arguments, spec, runner)
        if spec.get("schema_version", 1) != 1:
            raise CampaignError("unsupported campaign schema version")
        campaign = build_campaign(spec["provenance"], spec.get("float_tolerances"))
        canonical_json(campaign).encode("utf-8")
        executor = SubprocessExecutor(runner, arguments.timeout_seconds)
    except CampaignFailure as error:
        return _report_failure(error, arguments.output)
    except (CampaignError, KeyError, OSError, subprocess.SubprocessError, TypeError, ValueError):
        return _report_failure(
            CampaignFailure("campaign-spec", None, None, 0, 0, "invalid", "campaign input failed"),
            arguments.output,
        )
    try:
        runs = execute_campaign(campaign, executor)
        # The CLI owns these just-validated records; public callers may mutate theirs.
        summary = _write_validated_artifacts(campaign, runs, arguments.output)
    except CampaignFailure as error:
        return _report_failure(error, arguments.output, allow_partial=True)
    return 0 if summary["passed"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
