from pathlib import Path
import json,os,statistics,subprocess,sys,time
root=Path(__file__).resolve().parent
source=Path('/home/aunjbr/codebase/work/matrixone/build/mo28966-embedded-cutover')
state={'phase':'waiting-for-targeted-controls','passed':[]}
def save():
 (root/'final-qualification-state.json').write_text(json.dumps(state,indent=2)+'\n')
def run(name,resource=False):
 state['phase']=name;save()
 args=[sys.executable,str(source/'optools/sirius_campaign.py'),'run','--workspace',str(root/'candidate-workspace'),'--service',str(root/'candidate-release/mo-service'),'--runner','/home/aunjbr/codebase/work/matrixone/build/sirius-perf-release.zkConp/runner','--provenance',str(root/'candidate-provenance-ac6.json'),'--output',str(root/name)]
 if resource:args.append('--resource')
 with (root/(name+'.log')).open('w') as log:
  subprocess.run(args,cwd=source,stdout=log,stderr=subprocess.STDOUT,check=True)
 state['passed'].append(name);save()
try:
 save();deadline=time.monotonic()+1800
 controls=root/'resource-controls-ac6'
 while not (controls/'resource-diagnostic.json').exists():
  if (controls/'failure.json').exists():raise RuntimeError('targeted resource controls failed')
  if time.monotonic()>deadline:raise RuntimeError('targeted controls did not complete')
  time.sleep(1)
 profiles=[json.loads(p.read_text()) for p in controls.glob('resource-phase-*.json')]
 assert len(profiles)==2 and all(p['unexplained_growth_bytes']==0 and p['pool_baseline_reconciled'] for p in profiles)
 state['passed'].append('targeted-SF10-streams1-and4');save()
 run('candidate-timing-ac6')
 run('candidate-resource-ac6',True)
 before=json.loads((root/'baseline-provenance.json').read_text());after=json.loads((root/'candidate-provenance-ac6.json').read_text())
 for key in ('sirius_revision','sdk_sha256','query_sha256','datasets','hardware','config','toolchain','runner_binary_sha256','sdk_build_mode'):
  assert before[key]==after[key],key
 baseline=json.loads((root/'baseline-timing/summary.json').read_text());candidate=json.loads((root/'candidate-timing-ac6/summary.json').read_text())
 rows=[]
 for directory,count in (('baseline-timing',744),('candidate-timing-ac6',744),('candidate-resource-ac6',264)):
  values=[json.loads(line) for line in (root/directory/'runs.jsonl').read_text().splitlines()]
  assert len(values)==count;rows.extend(values)
 assert len({row['query_id'] for row in rows})==len(rows)
 profiles=[json.loads(p.read_text()) for p in sorted((root/'candidate-resource-ac6').glob('resource-phase-*.json'))]
 assert len(profiles)==6 and all(p['unexplained_growth_bytes']==0 and p['pool_baseline_reconciled'] for p in profiles)
 checks=[]
 for sf in ('SF1','SF10'):
  for metric in ('median_full_suite','sum_query_medians'):
   a,b=[d['scales'][sf]['embedded-mo'][metric] for d in (baseline,candidate)]
   checks.append({'scale':sf,'metric':metric,'baseline_seconds':a,'candidate_seconds':b,'ratio':b/a,'limit':1.05,'passed':b/a<=1.05})
 report={'baseline_provenance':before,'candidate_provenance':after,'timing_runs_each':744,'candidate_resource_runs':264,'resource_profiles':6,'unexplained_growth_bytes':[p['unexplained_growth_bytes'] for p in profiles],'explained_free_host_capacity_growth_bytes':[p['host_pool_reconciliation']['free_capacity_growth_bytes'] for p in profiles],'checks':checks,'passed':all(c['passed'] for c in checks)}
 (root/'matched-regression-final.json').write_text(json.dumps(report,indent=2)+'\n')
 assert report['passed'],'matched suite gate failed'
 state['phase']='complete';state['passed'].append('matched-performance-and-resource');save()
except BaseException as error:
 state['phase']='failed';state['error_type']=type(error).__name__;state['error']=str(error);save();raise
